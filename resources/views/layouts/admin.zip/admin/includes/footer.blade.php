<!-- Footer Start -->
<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <div>
                    <script>
                        document.write(new Date().getFullYear())
                    </script> © جميع الحقوق محفوظة إلي بسطات </a>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- end Footer -->
